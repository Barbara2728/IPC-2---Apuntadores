#include <stdio.h>

// REFERENCIACION: es la obtencion de la direccion de una variable 

int main() {
    int *ptr_intr;
    char *ptr_char;
    float *ptr_float;
    return 0;
}
  