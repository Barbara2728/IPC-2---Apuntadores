#include <stdio.h>

// REFERENCIACION: es la obtencion de la direccion de una variable 

int main() {
    int dir_var = 15;
    
    printf("La direccion d dir_var es: %p \n", &dir_var);
    return 0;
}
  