
#include <stdio.h>

int main() {

	float* ptr_float;

	printf("El valor apuntado por
		prt_float es % f", *ptr_float);

		return 0;

}

